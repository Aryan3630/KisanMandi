KisanMandi Android APK project

यह Android Studio / GitHub Actions से APK बनाने वाला प्रोजेक्ट है।
इसमें आपका HTML ऐप Android WebView के अंदर लोकल assets से चलता है।
- ऐप का नाम: KisanMandi
- Package: com.kisanmandi.app
- Minimum Android: 6.0 (API 23)
- ऐप डेटा WebView local storage में सेव होता है।
- इंटरनेट permission मौजूद है ताकि Tailwind CDN और बाहरी media URLs चल सकें।
- फोटो/वीडियो चुनने के लिए Android file picker bridge जोड़ा गया है।

APK बनाने का आसान तरीका (GitHub Actions):
1. इस ZIP को Extract करें।
2. पूरा KisanMandi_Android फ़ोल्डर GitHub पर नया repository बनाकर upload करें।
3. GitHub repository में Actions tab खोलें।
4. "Build KisanMandi APK" workflow चलाएं (या main branch पर push करें)।
5. Workflow पूरा होने पर Artifacts में KisanMandi-debug-apk डाउनलोड करें।
6. ZIP के अंदर app-debug.apk होगा। Android फोन में खोलकर install करें।
   फोन पूछे तो इस source से install की अनुमति दें।

Android Studio:
- Android Studio में यह फ़ोल्डर खोलें।
- Gradle sync होने दें।
- Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।

नोट:
- इस रनटाइम में Android SDK/Gradle उपलब्ध नहीं है, इसलिए अभी compiled APK नहीं, APK-build project दिया जा रहा है।
- आपका मौजूदा HTML demo PIN 1234 रखता है; production security के लिए server-side authentication आवश्यक है।
- डेटा इस फोन के ऐप में ही रहता है; कई फोन पर साझा/sync करने के लिए backend/database जोड़ना होगा।
- ऐप का कुछ कंटेंट और Tailwind CSS पहली बार internet मांग सकते हैं। पहले एक बार online खोलें ताकि CDN/cache उपलब्ध हो।
