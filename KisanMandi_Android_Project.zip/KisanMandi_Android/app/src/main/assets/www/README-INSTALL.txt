KisanMandi PWA - Android पर ऐप की तरह इंस्टॉल करें

इस पैकेज में आपकी KisanMandi वेबसाइट को PWA (Progressive Web App) बनाया गया है।
इसे Android पर ऐप की तरह इंस्टॉल किया जा सकता है और पहली बार ऑनलाइन खोलने के बाद मुख्य फाइलें कैश हो जाती हैं।

महत्वपूर्ण:
- यह APK फाइल नहीं है। Android APK बनाने के लिए Android SDK/बिल्ड वातावरण चाहिए।
- PWA इंस्टॉल करने के लिए इसे HTTPS होस्टिंग पर डालना होगा (जैसे GitHub Pages / Netlify)।
- पहली बार खोलते समय इंटरनेट जरूरी है। बाद में ऐप का मुख्य पेज और कैश हुई Tailwind फाइल ऑफलाइन खुल सकती है।
- मंडी पोस्ट/लाइक/कमेंट इसी डिवाइस के browser storage में सेव होते हैं; दूसरे फोन पर अपने-आप sync नहीं होंगे।
- Admin PIN अभी demo PIN 1234 है। असली सुरक्षा के लिए server-side login जरूरी है।
- फोटो/वीडियो के लिए ब्राउज़र स्टोरेज सीमित है; बड़े मीडिया अपलोड की स्थायी सेविंग की गारंटी नहीं है।

इंस्टॉल:
1. ZIP Extract करें।
2. पूरे KisanMandi फ़ोल्डर को HTTPS hosting पर अपलोड करें।
3. Android Chrome में वेबसाइट खोलें।
4. Chrome मेनू (⋮) > Install app / Add to Home screen चुनें।
5. होम स्क्रीन पर KisanMandi आइकन से ऐप खोलें।

फ़ाइलें:
- index.html: ऐप
- manifest.webmanifest: ऐप का नाम/आइकन/इंस्टॉल सेटिंग
- sw.js: ऑफलाइन cache
- icons/: ऐप आइकन और fallback image
